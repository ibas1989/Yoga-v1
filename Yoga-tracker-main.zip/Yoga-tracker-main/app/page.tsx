'use client';

import React, { useState } from 'react';
import { Plus } from 'lucide-react';
import { Calendar } from '@/components/Calendar';
import { SessionDialog } from '@/components/SessionDialog';
import { SessionDetailsDialog } from '@/components/SessionDetailsDialog';
import { StudentsView } from '@/components/StudentsView';
import { SettingsView } from '@/components/SettingsView';
import { Button } from '@/components/ui/button';
import { Users, Settings, Calendar as CalendarIcon } from 'lucide-react';
import { Session } from '@/lib/types';

export default function Home() {
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [view, setView] = useState<'calendar' | 'students' | 'settings'>('calendar');
  const [showSessionDialog, setShowSessionDialog] = useState(false);
  const [showSessionDetailsDialog, setShowSessionDetailsDialog] = useState(false);
  const [selectedSession, setSelectedSession] = useState<Session | null>(null);
  const [calendarRefresh, setCalendarRefresh] = useState(0);

  const handleDateSelect = (date: Date) => {
    setSelectedDate(date);
    setShowSessionDialog(true);
  };

  const handleSessionClick = (session: Session) => {
    setSelectedSession(session);
    setShowSessionDetailsDialog(true);
  };

  const handleSessionCreated = () => {
    setCalendarRefresh(prev => prev + 1);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-lg font-semibold">Yoga Class Tracker</h1>
            <nav className="flex gap-2">
              <Button
                variant={view === 'calendar' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setView('calendar')}
              >
                <CalendarIcon className="h-4 w-4 mr-2" />
                Calendar
              </Button>
              <Button
                variant={view === 'students' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setView('students')}
              >
                <Users className="h-4 w-4 mr-2" />
                Students
              </Button>
              <Button
                variant={view === 'settings' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setView('settings')}
              >
                <Settings className="h-4 w-4 mr-2" />
                Settings
              </Button>
            </nav>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {view === 'calendar' && (
          <div className="space-y-4">
            <div className="flex justify-end">
              <Button 
                onClick={() => {
                  setSelectedDate(new Date());
                  setShowSessionDialog(true);
                }}
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Session
              </Button>
            </div>
            <Calendar
              onDateSelect={handleDateSelect}
              onSessionClick={handleSessionClick}
              refreshTrigger={calendarRefresh}
            />
          </div>
        )}
        
        {view === 'students' && <StudentsView />}
        
        {view === 'settings' && <SettingsView />}
      </main>

      <SessionDialog
        open={showSessionDialog}
        onOpenChange={setShowSessionDialog}
        selectedDate={selectedDate}
        onSessionCreated={handleSessionCreated}
      />

      <SessionDetailsDialog
        open={showSessionDetailsDialog}
        onOpenChange={setShowSessionDetailsDialog}
        session={selectedSession}
      />
    </div>
  );
}

