'use client';

import React, { useState, useEffect } from 'react';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, isSameMonth, addMonths, subMonths, startOfWeek, endOfWeek } from 'date-fns';
import { ChevronLeft, ChevronRight, Plus } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Session } from '@/lib/types';
import { getSessions } from '@/lib/storage';
import { cn } from '@/lib/utils';

interface CalendarProps {
  onDateSelect: (date: Date) => void;
  onSessionClick: (session: Session) => void;
  refreshTrigger?: number;
}

export function Calendar({ onDateSelect, onSessionClick, refreshTrigger }: CalendarProps) {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [sessions, setSessions] = useState<Session[]>([]);

  useEffect(() => {
    loadSessions();
  }, [refreshTrigger]);

  const loadSessions = () => {
    setSessions(getSessions());
  };

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const calendarStart = startOfWeek(monthStart);
  const calendarEnd = endOfWeek(monthEnd);
  const calendarDays = eachDayOfInterval({ start: calendarStart, end: calendarEnd });

  const getSessionsForDate = (date: Date) => {
    return sessions.filter(session => isSameDay(new Date(session.date), date));
  };

  const handleDateClick = (date: Date) => {
    setSelectedDate(date);
    onDateSelect(date);
  };

  const previousMonth = () => {
    setCurrentMonth(subMonths(currentMonth, 1));
  };

  const nextMonth = () => {
    setCurrentMonth(addMonths(currentMonth, 1));
  };

  const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  return (
    <Card className="p-6">
      <div className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-base font-semibold">
            {format(currentMonth, 'MMMM yyyy')}
          </h2>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="icon"
              onClick={previousMonth}
              aria-label="Previous month"
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={nextMonth}
              aria-label="Next month"
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-7 gap-2 mb-2">
          {weekDays.map(day => (
            <div
              key={day}
              className="text-center text-sm font-medium text-muted-foreground py-2"
            >
              {day}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-7 gap-2 auto-rows-fr">
          {calendarDays.map((day, index) => {
            const daySessions = getSessionsForDate(day);
            const isCurrentMonth = isSameMonth(day, currentMonth);
            const isSelected = selectedDate && isSameDay(day, selectedDate);
            const isToday = isSameDay(day, new Date());

            return (
              <div
                key={index}
                className={cn(
                  "min-h-[100px] p-2 border rounded-md cursor-pointer transition-colors flex flex-col",
                  !isCurrentMonth && "bg-muted/50 text-muted-foreground",
                  isCurrentMonth && "hover:bg-accent",
                  isSelected && "ring-2 ring-primary",
                  isToday && "border-primary"
                )}
                onClick={() => handleDateClick(day)}
              >
                <div className={cn(
                  "text-sm font-medium mb-1 flex-shrink-0",
                  isToday && "text-primary"
                )}>
                  {format(day, 'd')}
                </div>
                <div className="space-y-1 flex-1 overflow-hidden">
                  {daySessions.slice(0, 10).map(session => (
                    <div
                      key={session.id}
                      className={cn(
                        "text-xs px-2 py-1 rounded truncate transition-colors hover:shadow-sm",
                        session.status === 'completed' && "bg-primary/20 text-primary hover:bg-primary/30",
                        session.status === 'scheduled' && "bg-secondary text-secondary-foreground hover:bg-secondary/80",
                        session.status === 'cancelled' && "bg-muted text-muted-foreground line-through"
                      )}
                      onClick={(e) => {
                        e.stopPropagation();
                        onSessionClick(session);
                      }}
                    >
                      {session.startTime}
                    </div>
                  ))}
                  {daySessions.length > 10 && (
                    <div className="text-xs text-muted-foreground px-2 font-medium">
                      +{daySessions.length - 10} more
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </Card>
  );
}

