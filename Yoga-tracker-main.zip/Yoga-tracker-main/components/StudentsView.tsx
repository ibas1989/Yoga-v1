'use client';

import React, { useState, useEffect } from 'react';
import { Plus, User } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Student } from '@/lib/types';
import { getStudents } from '@/lib/storage';
import { AddStudentDialog } from './AddStudentDialog';

export function StudentsView() {
  const [students, setStudents] = useState<Student[]>([]);
  const [showAddDialog, setShowAddDialog] = useState(false);

  useEffect(() => {
    loadStudents();
  }, []);

  const loadStudents = () => {
    setStudents(getStudents());
  };

  const handleStudentAdded = () => {
    loadStudents();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">Students</h2>
        <Button onClick={() => setShowAddDialog(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Add Student
        </Button>
      </div>

      {students.length === 0 ? (
        <Card>
          <CardContent className="pt-6">
            <div className="text-center py-12">
              <User className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <h3 className="text-base font-semibold mb-2">No students yet</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Add your first student to start tracking sessions.
              </p>
              <Button onClick={() => setShowAddDialog(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Add Student
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {students.map((student) => (
            <Card key={student.id} className="hover:shadow-md transition-shadow">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="text-base">{student.name}</span>
                  <span
                    className={`text-sm font-normal ${
                      student.balance > 0
                        ? 'text-destructive'
                        : student.balance < 0
                        ? 'text-primary'
                        : 'text-muted-foreground'
                    }`}
                  >
                    ${student.balance.toFixed(2)}
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  {student.email && (
                    <p className="text-muted-foreground truncate">
                      {student.email}
                    </p>
                  )}
                  {student.phone && (
                    <p className="text-muted-foreground">{student.phone}</p>
                  )}
                  {student.goals.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-3">
                      {student.goals.map((goal) => (
                        <span
                          key={goal}
                          className="inline-flex items-center rounded-full bg-primary/10 px-2 py-1 text-xs font-medium text-primary"
                        >
                          {goal}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <AddStudentDialog
        open={showAddDialog}
        onOpenChange={setShowAddDialog}
        onStudentAdded={handleStudentAdded}
      />
    </div>
  );
}

