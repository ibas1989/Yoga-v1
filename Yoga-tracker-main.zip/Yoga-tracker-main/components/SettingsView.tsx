'use client';

import React, { useState, useEffect } from 'react';
import { Save, Plus, X } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { AppSettings } from '@/lib/types';
import { getSettings, saveSettings } from '@/lib/storage';

export function SettingsView() {
  const [defaultPrice, setDefaultPrice] = useState('20');
  const [goals, setGoals] = useState<string[]>([]);
  const [newGoal, setNewGoal] = useState('');

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = () => {
    const settings = getSettings();
    setDefaultPrice(settings.defaultSessionPrice.toString());
    setGoals(settings.availableGoals);
  };

  const handleSave = () => {
    const settings: AppSettings = {
      defaultSessionPrice: parseFloat(defaultPrice) || 20,
      availableGoals: goals,
    };
    saveSettings(settings);
    alert('Settings saved successfully!');
  };

  const handleAddGoal = () => {
    if (newGoal.trim() && !goals.includes(newGoal.trim())) {
      setGoals([...goals, newGoal.trim()]);
      setNewGoal('');
    }
  };

  const handleRemoveGoal = (goalToRemove: string) => {
    setGoals(goals.filter(g => g !== goalToRemove));
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">Settings</h2>
        <Button onClick={handleSave}>
          <Save className="h-4 w-4 mr-2" />
          Save Settings
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Default Session Price</CardTitle>
          <CardDescription>
            This price will be used as the default for new sessions and automatic balance deductions.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <Label htmlFor="defaultPrice">Price per session ($)</Label>
            <Input
              id="defaultPrice"
              type="number"
              step="0.01"
              value={defaultPrice}
              onChange={(e) => setDefaultPrice(e.target.value)}
              placeholder="20.00"
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Session Goals/Tags</CardTitle>
          <CardDescription>
            Manage available goals that can be assigned to sessions and students.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex gap-2">
              <Input
                value={newGoal}
                onChange={(e) => setNewGoal(e.target.value)}
                placeholder="Add a new goal..."
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    handleAddGoal();
                  }
                }}
              />
              <Button onClick={handleAddGoal} size="sm">
                <Plus className="h-4 w-4" />
              </Button>
            </div>

            <div className="flex flex-wrap gap-2">
              {goals.map((goal) => (
                <div
                  key={goal}
                  className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-3 py-1.5 text-sm font-medium text-primary"
                >
                  {goal}
                  <button
                    onClick={() => handleRemoveGoal(goal)}
                    className="hover:bg-primary/20 rounded-full p-0.5 transition-colors"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ))}
            </div>

            {goals.length === 0 && (
              <p className="text-sm text-muted-foreground">
                No goals configured. Add your first goal above.
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

