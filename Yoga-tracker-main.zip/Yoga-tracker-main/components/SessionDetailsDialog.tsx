'use client';

import React, { useState, useEffect } from 'react';
import { format } from 'date-fns';
import { Clock, User, Tag, DollarSign, FileText, Calendar as CalendarIcon } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Session, Student } from '@/lib/types';
import { getStudents } from '@/lib/storage';

interface SessionDetailsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  session: Session | null;
}

export function SessionDetailsDialog({
  open,
  onOpenChange,
  session,
}: SessionDetailsDialogProps) {
  const [students, setStudents] = useState<Student[]>([]);

  useEffect(() => {
    if (open && session) {
      loadStudents();
    }
  }, [open, session]);

  const loadStudents = () => {
    const allStudents = getStudents();
    setStudents(allStudents);
  };

  if (!session) return null;

  const sessionStudents = students.filter(s => session.studentIds.includes(s.id));

  const getStatusBadge = (status: Session['status']) => {
    const styles = {
      scheduled: 'bg-secondary text-secondary-foreground',
      completed: 'bg-primary/20 text-primary',
      cancelled: 'bg-muted text-muted-foreground',
    };

    return (
      <span className={`inline-flex items-center rounded-full px-3 py-1 text-xs font-medium ${styles[status]}`}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </span>
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle>Session Details</DialogTitle>
            {getStatusBadge(session.status)}
          </div>
          <DialogDescription>
            {format(new Date(session.date), 'EEEE, MMMM d, yyyy')}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Time Information */}
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <Clock className="h-5 w-5 text-muted-foreground mt-0.5" />
              <div className="flex-1">
                <p className="text-sm font-medium">Time</p>
                <p className="text-sm text-muted-foreground">
                  {session.startTime} - {session.endTime}
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <DollarSign className="h-5 w-5 text-muted-foreground mt-0.5" />
              <div className="flex-1">
                <p className="text-sm font-medium">Price Per Student</p>
                <p className="text-sm text-muted-foreground">
                  ${session.pricePerStudent.toFixed(2)}
                </p>
              </div>
            </div>
          </div>

          {/* Students Section */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <User className="h-5 w-5 text-muted-foreground" />
              <p className="text-sm font-medium">
                Attendees ({sessionStudents.length})
              </p>
            </div>
            <div className="space-y-2 pl-7">
              {sessionStudents.length === 0 ? (
                <p className="text-sm text-muted-foreground">No students assigned</p>
              ) : (
                sessionStudents.map((student) => (
                  <Card key={student.id} className="hover:shadow-sm transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <p className="text-sm font-medium">{student.name}</p>
                          <p className="text-xs text-muted-foreground">
                            Current Balance: ${student.balance.toFixed(2)}
                          </p>
                          {student.goals.length > 0 && (
                            <div className="flex flex-wrap gap-1 mt-2">
                              {student.goals.map((goal) => (
                                <span
                                  key={goal}
                                  className="inline-flex items-center rounded-full bg-muted px-2 py-0.5 text-xs"
                                >
                                  {goal}
                                </span>
                              ))}
                            </div>
                          )}
                        </div>
                        {session.balanceEntries[student.id] !== undefined && (
                          <div className="text-right ml-4">
                            <p className="text-xs text-muted-foreground">Paid</p>
                            <p className="text-sm font-medium">
                              {session.balanceEntries[student.id] === null
                                ? 'Not entered'
                                : `$${session.balanceEntries[student.id]?.toFixed(2)}`}
                            </p>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </div>

          {/* Session Goals */}
          {session.goals && session.goals.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Tag className="h-5 w-5 text-muted-foreground" />
                <p className="text-sm font-medium">Session Goals</p>
              </div>
              <div className="flex flex-wrap gap-2 pl-7">
                {session.goals.map((goal) => (
                  <span
                    key={goal}
                    className="inline-flex items-center rounded-full bg-primary/10 px-3 py-1 text-sm font-medium text-primary"
                  >
                    {goal}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Notes */}
          {session.notes && (
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-muted-foreground" />
                <p className="text-sm font-medium">Notes</p>
              </div>
              <p className="text-sm text-muted-foreground pl-7">{session.notes}</p>
            </div>
          )}

          {/* Session Metadata */}
          <div className="border-t pt-4">
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <CalendarIcon className="h-4 w-4" />
              <span>
                Created on {format(new Date(session.createdAt), 'MMM d, yyyy')}
              </span>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Close
          </Button>
          {session.status === 'scheduled' && (
            <>
              <Button variant="outline">Edit Session</Button>
              <Button>Complete Session</Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

