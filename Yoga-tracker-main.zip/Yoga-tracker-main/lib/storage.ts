import { Student, Session, AppSettings } from './types';

const STUDENTS_KEY = 'yoga_tracker_students';
const SESSIONS_KEY = 'yoga_tracker_sessions';
const SETTINGS_KEY = 'yoga_tracker_settings';

// Default settings
const defaultSettings: AppSettings = {
  defaultSessionPrice: 20,
  availableGoals: [
    'Flexibility',
    'Strength',
    'Balance',
    'Stress Relief',
    'Weight Loss',
    'Meditation',
    'Core Work',
    'Back Pain Relief'
  ]
};

// Students
export const getStudents = (): Student[] => {
  if (typeof window === 'undefined') return [];
  const data = localStorage.getItem(STUDENTS_KEY);
  if (!data) return [];
  const students = JSON.parse(data);
  return students.map((s: any) => ({
    ...s,
    createdAt: new Date(s.createdAt)
  }));
};

export const saveStudent = (student: Student): void => {
  const students = getStudents();
  const index = students.findIndex(s => s.id === student.id);
  if (index >= 0) {
    students[index] = student;
  } else {
    students.push(student);
  }
  localStorage.setItem(STUDENTS_KEY, JSON.stringify(students));
};

export const deleteStudent = (studentId: string): void => {
  const students = getStudents().filter(s => s.id !== studentId);
  localStorage.setItem(STUDENTS_KEY, JSON.stringify(students));
};

// Sessions
export const getSessions = (): Session[] => {
  if (typeof window === 'undefined') return [];
  const data = localStorage.getItem(SESSIONS_KEY);
  if (!data) return [];
  const sessions = JSON.parse(data);
  return sessions.map((s: any) => ({
    ...s,
    date: new Date(s.date),
    createdAt: new Date(s.createdAt),
    goals: s.goals || [] // Ensure goals array exists for older data
  }));
};

export const saveSession = (session: Session): void => {
  const sessions = getSessions();
  const index = sessions.findIndex(s => s.id === session.id);
  if (index >= 0) {
    sessions[index] = session;
  } else {
    sessions.push(session);
  }
  localStorage.setItem(SESSIONS_KEY, JSON.stringify(sessions));
};

export const deleteSession = (sessionId: string): void => {
  const sessions = getSessions().filter(s => s.id !== sessionId);
  localStorage.setItem(SESSIONS_KEY, JSON.stringify(sessions));
};

// Settings
export const getSettings = (): AppSettings => {
  if (typeof window === 'undefined') return defaultSettings;
  const data = localStorage.getItem(SETTINGS_KEY);
  if (!data) return defaultSettings;
  return JSON.parse(data);
};

export const saveSettings = (settings: AppSettings): void => {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
};

// Close session and update student balances
export const closeSession = (sessionId: string): void => {
  const sessions = getSessions();
  const students = getStudents();
  const session = sessions.find(s => s.id === sessionId);
  
  if (!session || session.status === 'completed') return;
  
  const settings = getSettings();
  
  // Update student balances
  session.studentIds.forEach(studentId => {
    const student = students.find(s => s.id === studentId);
    if (!student) return;
    
    const balancePaid = session.balanceEntries[studentId];
    if (balancePaid === null || balancePaid === undefined) {
      // No balance entered, deduct default price
      student.balance += session.pricePerStudent || settings.defaultSessionPrice;
    } else {
      // Balance was entered, add the difference
      const priceOwed = session.pricePerStudent || settings.defaultSessionPrice;
      student.balance += priceOwed - balancePaid;
    }
    
    saveStudent(student);
  });
  
  // Mark session as completed
  session.status = 'completed';
  saveSession(session);
};

