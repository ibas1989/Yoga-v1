export interface Student {
  id: string;
  name: string;
  email: string;
  phone: string;
  balance: number; // Positive means they owe money, negative means credit
  goals: string[];
  createdAt: Date;
}

export interface Session {
  id: string;
  date: Date;
  startTime: string;
  endTime: string;
  studentIds: string[];
  goals: string[]; // Session goals/tags
  pricePerStudent: number;
  status: 'scheduled' | 'completed' | 'cancelled';
  balanceEntries: Record<string, number | null>; // studentId -> balance paid (null if not entered)
  notes: string;
  createdAt: Date;
}

export interface AppSettings {
  defaultSessionPrice: number;
  availableGoals: string[];
}

